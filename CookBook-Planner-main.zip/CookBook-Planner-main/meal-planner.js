function addNewMeal() {
    const day = document.getElementById('day').value;
    const breakfast = document.getElementById('breakfast').value;
    const lunch = document.getElementById('lunch').value;
    const dinner = document.getElementById('dinner').value;
    const snacks = document.getElementById('snacks').value;


    const daySection = document.querySelector(`#planner .${day.toLowerCase()}`);
    if (daySection) {
        daySection.innerHTML = `
            <p>Breakfast: ${breakfast}</p>
            <p>Lunch: ${lunch}</p>
            <p>Dinner: ${dinner}</p>
            <p>Snacks: ${snacks}</p>
        `;
    }
}

async function addMealToList(event) {
    event.preventDefault();

    const mealName = document.getElementById('mealName').value;
    const mealIngredient = document.getElementById('mealIncredient').value;
    const mealProcedure = document.getElementById('mealProcedure').value;

    try {
        await fetch('http://localhost:3000/recipes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: mealName,
                ingredients: mealIngredient,
                procedur: mealProcedure
            })
        });

        document.getElementById('mealName').value = '';
        document.getElementById('mealIncredient').value = '';
        document.getElementById('mealProcedure').value = '';
        fetchAndDisplayMeals(); 
    } catch (error) {
        console.error('Error adding meal:', error);
    }
}

async function fetchAndDisplayMeals() {
    const mealList = document.getElementById('meal-list');
    mealList.innerHTML = ''; 

    try {
        
        const response = await fetch('http://localhost:3000/recipes');
        const meals = await response.json();

        
        meals.forEach(meal => {
            const mealItem = document.createElement('div');
            mealItem.classList.add('meal-item', 'border', 'p-2', 'mb-2');
            mealItem.innerHTML = `
                <h5>${meal.name}</h5>
                <p>Ingredients: ${meal.ingredients}</p>
                <p>Procedure: ${meal.procedur}</p>
                <button class="delete-btn" onclick="deleteMeal(${meal.id})">Delete</button>
                <button class="edit-btn" onclick="editMeal(${meal.id}, '${meal.name}', '${meal.ingredients}', '${meal.procedur
                }')">Edit</button>
            `;
            mealList.appendChild(mealItem);
        });
    } catch (error) {
        console.error('Error fetching meals:', error);
    }
}


async function deleteMeal(id) {
    try {
        const response = await fetch(`http://localhost:3000/recipes/${id}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            console.log(`Meal with ID ${id} deleted successfully.`);
            fetchAndDisplayMeals(); 
        } else {
            console.error('Error deleting meal:', response.statusText);
        }
    } catch (error) {
        console.error('Error deleting meal:', error);
    }
}

function editMeal(id, name, ingredients, procedure) {
    
    document.getElementById('mealName').value = name;
    document.getElementById('mealIncredient').value = ingredients;
    document.getElementById('mealProcedure').value = procedure;

    
    document.getElementById('mealId').value = id;

   
    document.getElementById('submitMeal').textContent = 'Update Meal';
    document.getElementById('submitMeal').onclick = function (event) {
        event.preventDefault();
        updateMeal();
    };
}


async function updateMeal() {
    const id = document.getElementById('mealId').value;
    const updatedName = document.getElementById('mealName').value;
    const updatedIngredients = document.getElementById('mealIncredient').value;
    const updatedProcedure = document.getElementById('mealProcedure').value;

    try {
        const response = await fetch(`http://localhost:3000/recipes/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: updatedName,
                ingredients: updatedIngredients,
                procedur: updatedProcedure
            })
        });

        if (response.ok) {
            console.log(`Meal with ID ${id} updated successfully.`);
            fetchAndDisplayMeals(); 

            
            document.getElementById('mealName').value = '';
            document.getElementById('mealIncredient').value = '';
            document.getElementById('mealProcedure').value = '';
            document.getElementById('submitMeal').textContent = 'Add Meal';
            document.getElementById('submitMeal').onclick = addMealToList;
        } else {
            console.error('Error updating meal:', response.statusText);
        }
    } catch (error) {
        console.error('Error updating meal:', error);
    }
}


document.addEventListener('DOMContentLoaded', fetchAndDisplayMeals);
document.getElementById('meal-form').addEventListener('submit', addMealToList);
document.getElementById('saveBtn').addEventListener('click', addNewMeal);
