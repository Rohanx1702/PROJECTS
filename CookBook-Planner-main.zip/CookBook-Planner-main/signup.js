document.getElementById('signup-form').addEventListener('submit', async (event) => {
    event.preventDefault();  

    const fullName = document.getElementById('full-name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }

    const data = {
        full_name: fullName,
        email: email,
        password: password
    };

    try {
       
        const response = await fetch('http://localhost:3000/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            alert('Account created successfully!');
          
            window.location.href = 'signin.html';
        } else {
            alert(result.message || 'Failed to create account.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while creating the account.');
    }
});
