document.getElementById('signin-form').addEventListener('submit', async (event) => {
    event.preventDefault(); 

    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const data = {
        email: email,
        password: password
    };

    try {
       
        const response = await fetch('http://localhost:3000/signin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            alert('Sign in successful!');
            
           
            localStorage.setItem('user', JSON.stringify(result.user));  
            localStorage.setItem('authToken', result.token);  

            window.location.href = 'index.html';  
        } else {
            alert(result.message || 'Failed to sign in.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while signing in.');
    }
});
