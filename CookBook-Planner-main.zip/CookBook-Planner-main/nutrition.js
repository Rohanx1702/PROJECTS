document.addEventListener("DOMContentLoaded", async function () {
    try {
       
        const response = await fetch(`http://localhost:3000/nutrition`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        const nutritionData = await response.json();

       
        document.getElementById('calories-display').textContent = nutritionData.calories;
        document.getElementById('protein-display').textContent = nutritionData.protein;
        document.getElementById('carbs-display').textContent = nutritionData.carbs;
        document.getElementById('fats-display').textContent = nutritionData.fats;

       
        document.getElementById('calories').value = nutritionData.calories;
        document.getElementById('protein').value = nutritionData.protein;
        document.getElementById('carbs').value = nutritionData.carbs;
        document.getElementById('fats').value = nutritionData.fats;
    } catch (error) {
        console.error('Error fetching nutrition data:', error);
    }
});

document.getElementById('nutrition-form').addEventListener('submit', async function (event) {
    event.preventDefault();

    
    const calories = document.getElementById('calories').value;
    const protein = document.getElementById('protein').value;
    const carbs = document.getElementById('carbs').value;
    const fats = document.getElementById('fats').value;
    const id = 1;
    try {
        
        const response = await fetch('http://localhost:3000/nutrition', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id, calories, protein, carbs, fats }),
        });

        if (!response.ok) {
            throw new Error('Failed to update nutrition data');
        }

       
        document.getElementById('calories-display').textContent = calories;
        document.getElementById('protein-display').textContent = protein;
        document.getElementById('carbs-display').textContent = carbs;
        document.getElementById('fats-display').textContent = fats;

    } catch (error) {
        console.error('Error updating nutrition data:', error);
    }
});
