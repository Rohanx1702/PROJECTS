document.getElementById('logout').addEventListener('click', function () {
   
    localStorage.removeItem('user'); 

   
    window.location.href = 'signin.html';
});
