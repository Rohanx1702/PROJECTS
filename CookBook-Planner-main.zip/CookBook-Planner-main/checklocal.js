document.addEventListener('DOMContentLoaded', function () {
    
    const userData = localStorage.getItem('user');  
    const signupLink = document.getElementById('signup-link');
    const logoutLink = document.getElementById('logout');

    if (userData) {
       
        signupLink.style.display = 'none';
        logoutLink.style.display = 'block'; 
    } else {
        
        signupLink.style.display = 'block';
        logoutLink.style.display = 'none';  
    }
});
